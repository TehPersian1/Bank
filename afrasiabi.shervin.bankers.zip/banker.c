// Banker.c -- An Implementation of the Bankers Algorithm
// By Shervin Afrasiabi CPSC 351 T/TH 1:00pm - 2:15pm
// CWID 887958510

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define NUMBER_OF_CUSTOMERS 3
#define NUMBER_OF_RESOURCES 4
#define INIT_FILE "infile.txt"

int available[NUMBER_OF_RESOURCES];
int need[NUMBER_OF_CUSTOMERS][NUMBER_OF_RESOURCES];
int max[NUMBER_OF_CUSTOMERS][NUMBER_OF_RESOURCES];
int allocated[NUMBER_OF_CUSTOMERS][NUMBER_OF_RESOURCES];


//numbers_check() - This algorithm will check to ensure the 1st parameter is smaller than the 2nd
// this check will be used to ensure that the number of resources requested never exceeds the max available
// as well as ensuring the requested resources doesnt exceed the max needed.
int numbers_check(int *x, int *y, int z) {
    for(int i = 0 ; i != z; ++i) {
        if(x[i] > y[i]) {
            return 0;
        }
    }
    return 1;
}

// deadlock() - this will check both the arrays by implementing numbers_check above,
// this will be the actual meat of the program that ensures that numbers don't exceed their limits
// by comparing the work, available, need matricies, if anything doesn't pass the numbers_check()
// an error is set indicating the procedure requested is not safe and should not be executed
// it will also make sure any one customer does not hold onto too many resources at once without allowing
// other customers to progress due to a lack of resources. We use memcpy to copy the value of available matrix
// to the work matrix safely, and we use memset to create the "finish" array process_filed to all 0, keeping track
// of which customers are still working for resources.
int deadlock() {
    int work[NUMBER_OF_RESOURCES], finish[NUMBER_OF_CUSTOMERS];
    memcpy(work, available, NUMBER_OF_RESOURCES * sizeof(int));
    memset(finish, 0, NUMBER_OF_CUSTOMERS * sizeof(int));
    for(int k = 0; k != NUMBER_OF_CUSTOMERS; ++k) {
        int error = 0;
        for(int i = 0; i != NUMBER_OF_CUSTOMERS; ++i) {
            if(finish[i] == 0 && numbers_check(need[i], work, NUMBER_OF_RESOURCES)) {
                error = 1;
                finish[i] = 1;
                for(int j = 0; j != NUMBER_OF_RESOURCES; ++j) {
                    work[j] += allocated[i][j];
                }
                break;
            }
        }
        if(!error) {
            return 0;
        }
    }
    return 1;
}

// withdraw_resources() - This function is the main procedure when "RQ" is called in the console.
// it will be passed the customer # followed by the number of resources to be requested as parameters
// the function will first check to ensure resources are available, and make the changes necessary
// in each matrix. If an error occurs, It will print the reason behind the error, return an error code
// as well as implement a rollback feature to prevent any change to the data. 
// error code:
// -1 = invalid # of resources requested
// -2 = not enough resources for request
// -3 = resources requested exceeds # available (potential deadlock)
int withdraw_resources(int customer, int request[NUMBER_OF_RESOURCES]) {
    if(customer < 0 || customer >= NUMBER_OF_CUSTOMERS) {
        printf("Invalid customer: %d\n", customer);
        return -1;
    }
    int error = 0;
    for(int i = 0; i != NUMBER_OF_RESOURCES; ++i) {
        if(request[i] < 0 || request[i] > need[customer][i]) {
            printf("Invalid number of resources requested:\n|Customer: %d, Resource: %d, Need: %d, Withdraw: %d|\n",
            	customer, i, need[customer][i], request[i]);
            error = -1;
        }
        if(request[i] > available[i]) {
            printf("Not enough resources available for request:\n|Customer: %d, Resource: %d, Available: %d, Withdraw: %d|\n",
            	customer, i, available[i], request[i]);
            error = -2;
        }
        if(error != 0) { // this is the rollback mentioned in the description in case of any errors, preventing unwanted changes
            while(i--) {
                available[i] += request[i];
                allocated[customer][i] -= request[i];
                need[customer][i] += request[i];
            }
            return error;
        }
        
        available[i] -= request[i];
        allocated[customer][i] += request[i];
        need[customer][i] -= request[i];
    }
    if(!deadlock()) { // another rollback this looks confusing because of !deadlock, but its really not passing deadlock check
        printf("Potential Deadlock Avoided - Not Enough Resources to Complete Other Jobs!\n");
        for(int i = 0; i != NUMBER_OF_RESOURCES; ++i) {
            available[i] += request[i];
            allocated[customer][i] -= request[i];
            need[customer][i] += request[i];
        }
        return -3;
    }
    return 0;
}

// This wrapper function is very basic, it makes the calls in main() that "drive" out program.
// They will call the Request/Release functions respectively, as well as write to the log whether
// the process was a success, or if it was denied.
void withdraw_wrapper() {
    int request[NUMBER_OF_RESOURCES], customer;
    scanf("%d", &customer);
    for(int i = 0; i != NUMBER_OF_RESOURCES; ++i) {
        scanf("%d", &request[i]);
    }
    if(withdraw_resources(customer, request) != 0) {
        printf("---> Denied\n");
    } else {
        printf("---> Approved\n");
        
    }
}


// deposit_resources() - The main procedure when "RL" is called in the console.
// it will take a customer # as well as the number of resources to be released as a parameter.
// the function will first check to ensure the resources are being held by said customer and do not
// release more than what is possible. There is also some basic error checking in place.
int deposit_resources(int customer, int release[NUMBER_OF_RESOURCES]) {
    if(customer < 0 || customer >= NUMBER_OF_CUSTOMERS) {
        printf("Invalid customer: %d\n", customer);
        return -1;
    }
    for(int i = 0; i != NUMBER_OF_RESOURCES; ++i) {
        if(release[i] < 0 || release[i] > allocated[customer][i]) {
            printf("Invalid number of resources to release:\n|Customer: %d, Resource: %d, Allocated: %d, Deposit: %d|\n",customer, i, allocated[customer][i], release[i]);
            while(i--) {
                allocated[customer][i - 1] += release[i - 1];
                available[i] -= release[i];
            }
            return -1;
        }
        allocated[customer][i] -= release[i];
        available[i] += release[i];
    }
    return 0;
}

// This is the other wrapper function that will drive our program in main().
// it will print the result of our release request as either denied or approved
// if de
void deposit_wrapper() {
    int release[NUMBER_OF_RESOURCES], customer;
    scanf("%d", &customer);
    for(int i = 0; i != NUMBER_OF_RESOURCES; ++i) {
        scanf("%d", &release[i]);
    }
    if(deposit_resources(customer, release) != 0) {
        printf("---> Denied\n");
    } else {
        printf("---> Approved\n");
    }
}

// basic instructions on how to use the program, most likely won't need this as I will include
// screenshot examples in my submission, unless you want to test it for yourself.
void instructions() {
    printf("*************************************************************\n");
    printf("Instructions:\n");
    printf("    Request resources: RQ <customer #0-%d> <%d resources>\n", NUMBER_OF_CUSTOMERS -1,NUMBER_OF_RESOURCES);
    printf("    Release resources: RL <customer #0-%d> <%d resources>\n", NUMBER_OF_CUSTOMERS -1,NUMBER_OF_RESOURCES);
    printf("    Enter \"V\" at any time to view the current list of resources\n");
    printf("*************************************************************\n\n");
}

// this function is incorporated into the show() function below, it will notify us if a customer
// has all of their requested resources and can safely release all of their resources and shutdown
// it will also output to the bank when all customers have completed their requests and the program can safely shutdown
void needs_met(){
	int all_done = 1;
	for(int customer = 0; customer != NUMBER_OF_CUSTOMERS; ++customer) {
	int needs_met = 0; 
        for(int i = 0; i != NUMBER_OF_RESOURCES; ++i) {
            if((need[customer][i]   == 0 && allocated[customer][i]   > 0) &&
               (need[customer][i-1] == 0 && allocated[customer][i-1] > 0) &&
               (need[customer][1]   == 0 && allocated[customer][1]   > 0) && 
               (need[customer][0]   == 0 && allocated[customer][0]   > 0))
            {needs_met=1;}
            else
            {needs_met=0;
            all_done=0;}
        }
        if(needs_met == 1){
        printf("Customer %d Has all of their resources! Release all and shutdown with \"RL\"\n", customer);
        }
        if(all_done == 1){
        printf("Requests Complete... shutting down");
        }
      }
    }

// show() - This is our output function - - - - - - -
// It will display info about our currently available resources, followed by our
// our customer list and their respective need, max, and allocated arrays
// this will be displayed after every transaction for clarity purposes
void show() {
    printf("\n");
    printf("Resources Currently Available:\n");
    for(int i = 0; i != NUMBER_OF_RESOURCES; ++i) {
        printf("%d ", available[i]);
    }
    printf("\n- - - - - - - - - - - - - - - - - - - - - - - - - - - \n");
    printf("Cust\t Maximum \t Allocated \t Needed\n");
    for(int customer = 0; customer != NUMBER_OF_CUSTOMERS; ++customer) {
        printf(" %d: ", customer);
        printf("\t[");
        for(int i = 0; i != NUMBER_OF_RESOURCES; ++i) {
            printf(" %d", max[customer][i]);
        }
        printf(" ]\t[");
        for(int i = 0; i != NUMBER_OF_RESOURCES; ++i) {
            printf(" %d", allocated[customer][i]);
        }
        printf(" ]\t[");
        for(int i = 0; i != NUMBER_OF_RESOURCES; ++i) {
            printf(" %d", need[customer][i]);
        }
        printf(" ]\n");
    }
    printf("\n");
    needs_met();
    printf("\n");
}




// process_file() - this will take our application parameters (the number of starting resources)
// as well as the resources_file declared at the top, and will build all of the matricies necessary
// for the program's main execution. It will output an error if it is unable to build matricies/find the file.
// The programs infile is currently adjusted to support 6 customers with 6 maximum resources ---
// to make these changes make sure you adjust the NUMBER_OF_CUSTOMERS & NUMBER_OF_RESOURCES at the top of the file.
int process_file(int argc, char *argv[], const char *resources_file) {
    if(argc != 1 + NUMBER_OF_RESOURCES) {
        printf("Incorrect number of parameters.\n");
        return -1;
    }
    for(int i = 0; i != NUMBER_OF_RESOURCES; ++i) {
        available[i] = atoi(argv[i + 1]);
    }
    FILE *f = fopen(resources_file, "r");
    if(f == NULL) {
        printf("Unable to open file: %s\n", resources_file);
        return -2;
    }
    for(int c = 0; c != NUMBER_OF_CUSTOMERS; ++c) {
        for(int r = 0; r != NUMBER_OF_RESOURCES; ++r) {
            fscanf(f, "%d", &max[c][r]);
            need[c][r] = max[c][r];
        }
    }
    fclose(f);
    printf("Resources process_filed from file:%s\n%d Customers Loaded....\nWaiting for Request...\n",
    	INIT_FILE, NUMBER_OF_CUSTOMERS);
    return 0;
}
		

//Our main execution, will take a parameter at program launch dictating how much of each resource
// will be available during program runtime. I was having trouble implementing a random number gen
// that worked well with this program so i opted for manual input of the parameters. It kind of goes against
// the purpose of implementing this with pthreads factory running automatically, but at least it will show 
//understanding of the key concepts required to implement the algorithm. basic input is handled with a char
// stream called input[]
int main(int argc, char *argv[]) {
    if(process_file(argc, argv, INIT_FILE) != 0) {
        instructions();
        return 0;
    }
    char input[5];
    instructions();
    printf("Bank> ");
    while(scanf("%s", input) == 1) {
        if(strcmp(input, "RQ") == 0 || strcmp(input, "rq") == 0) {
            withdraw_wrapper();
            
        }
        else if(strcmp(input, "RL") == 0 || strcmp(input, "rl") == 0) {
            deposit_wrapper();
           
        }
        else if(strcmp(input, "V") == 0 || strcmp(input, "v") == 0 || strcmp(input, "show") == 0) {
            show();
        }
        else {
            instructions();
        }
        printf("Bank> ");
    }
    return 0;
}
